import { Component } from "react";
import ContentContainerAdd from "./Content/ContentContainerAdd";
import ContentBiletList from "./ContentBilet/ContentBiletsList";
import {BrowserRouter} from "react-router-dom";

export default class Content extends Component {
    render () {
        return(
            <div>
                <BrowserRouter>
                    <ContentContainerAdd movie={this.props.movie} poster={this.props.movie.poster_path}/>
                    <ContentBiletList movie={this.props.list}/>
                    
                </BrowserRouter>
            </div>
        )
    }
}