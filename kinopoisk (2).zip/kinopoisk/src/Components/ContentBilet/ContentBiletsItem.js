

const ContentBiletItem = (props) => {

	let dete = props.movie.release_date.split("-")
	let style1 = {
		backgroundColor: "gray"
	}

	if (props.movie.vote_average <= 2) {
		style1.backgroundColor = "gray"
	} else if(props.movie.vote_average <= 4) {
		style1.backgroundColor = "red";
	} else if (props.movie.vote_average <= 6) {
		style1.backgroundColor = "yellow";
	} else if (props.movie.vote_average <= 8) {
		style1.backgroundColor = "lightgreen"
	} else {
		style1.backgroundColor = "#f16df1"
	}

	if(dete[1] == "01") {
		dete[1] = " января "
	} else if (dete[1] == "02") {
		dete[1] = " февраля "
	} else if (dete[1] == "03") {
		dete[1] = " марта "
	} else if (dete[1] == "04") {
		dete[1] = " апреля "
	} else if (dete[1] == "05") {
		dete[1] = " мая "
	} else if (dete[1] == "06") {
		dete[1] = " июня "
	} else if (dete[1] == "07") {
		dete[1] = " июля "
	} else if (dete[1] == "08") {
		dete[1] = " апреля "
	} else if (dete[1] == "09") {
		dete[1] = " сентебря "
	} else if (dete[1] == "10") {
		dete[1] = " октября "
	} else if (dete[1] == "11") {
		dete[1] = " ноября "
	} else if (dete[1] == "12") {
		dete[1] = " декабря "
	} 
	
	if(dete[2] == "01") {
		dete[2] = "1"
	} else if (dete[2] == "02") {
		dete[2] = "2"
	} else if (dete[2] == "03") {
		dete[2] = "3"
	} else if (dete[2] == "04") {
		dete[2] = "4"
	} else if (dete[2] == "05") {
		dete[2] = "5"
	} else if (dete[2] == "06") {
		dete[2] = "6"
	} else if (dete[2] == "07") {
		dete[2] = "7"
	} else if (dete[2] == "08") {
		dete[2] = "8"
	} else if (dete[2] == "09") {
		dete[2] = "9"
	}

	

	let dute = [dete[2], dete[1], dete[0], " года"]
	
	return (
			<div className="movie_box">
				<p className="movie_vote_average" style={style1}>{props.movie.vote_average}</p>
				<img className="movie_poster" src={props.movie.poster_link} alt="movie poster"/>
				<div id="txt">
					<div>
						<p className="movie_title">{props.movie.title}</p>
						<p>{dute}</p>
					</div>
				</div>
			</div>
	)
}

export default ContentBiletItem;