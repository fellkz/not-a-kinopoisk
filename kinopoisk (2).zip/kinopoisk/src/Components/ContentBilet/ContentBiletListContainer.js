import Slider from "react-slick";

const ContentBiletListContainer = (props) => {

	var settings = {
		dots: true,
		infinite: true,
		autoplay: true,
		speed: 2000,
		autpolaySpeed: 2000,
		slidesToShow: 6,
		slidesToScroll: 2,
		initialSlide: 0,
		arrows: true ,
		responsive: [
		  {
			breakpoint: 1024,
			settings: {
			  slidesToShow: 3,
			  slidesToScroll: 3,
			  infinite: false,
			  dots: true
			}
		  },
		  {
			breakpoint: 600,
			settings: {
			  slidesToShow: 2,
			  slidesToScroll: 2,
			  initialSlide: 2
			}
		  },
		  {
			breakpoint: 480,
			settings: {
			  slidesToShow: 1,
			  slidesToScroll: 1
			}
		  }
		]
	  };

	return (
		<div className="movie_box_container">
			<Slider {...settings} className="aboba">
				    {props.movies}
			</Slider>	
		</div>
	)

}

export default ContentBiletListContainer;

