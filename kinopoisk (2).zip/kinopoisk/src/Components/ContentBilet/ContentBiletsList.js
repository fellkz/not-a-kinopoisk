import { Component } from "react";
import ContentBiletListContainer from "./ContentBiletListContainer";
import "./index.css";

export default class ContentBiletList extends Component{
    constructor(props) {
        super(props)
    }

    symbol = ">";


    render(){
        return(
            <div id="biletsList">
                <h3 className="bilets">Билеты в кино <span id="symbol">{this.symbol}</span></h3>
                <ContentBiletListContainer movies={this.props.movie}/>
            </div>
        )
    }
}