import React, { Component } from "react";

export default class Header extends Component {

	constructor(props){
		super(props)
	}

	scrollToMovies = () => {
        let element = document.querySelector(".movie_main");
        let headerOffset = 78;
        let elementPosition = element.OffsetTop;
        let offsetPosition = (elementPosition = headerOffset);
        document.documentElement.scroll = offsetPosition;
        document.body.scrollTop = offsetPosition;
    };


	render(){
		return(
			<div>
				<header>
					<div id="container">
						<div>
							<img id="logo" src="https://upload.wikimedia.org/wikipedia/commons/thumb/c/c1/Kinopoisk_colored_logo_%282021-present%29.svg/2560px-Kinopoisk_colored_logo_%282021-present%29.svg.png" alt=""/>
						</div>
						<div id="extra_hud">
							<div className="extra_hud-hover flex">
								<img/>
								<span>Онлайн кинатеатр</span>
							</div>
							<div className="extra_hud-hover flex">
								<img/>
								<span>Установить на ТВ</span>
							</div>
							<input id="extra-hud_input" placeholder="Фильмы, сериалы, персоны..." className="flex search-filed" type="search"  name="search" onFocus={()=> this.scrollToMovies()} />
						</div>
						<div id="register-and-login">
							<button className="try">Попробовать плюс</button>
							<span id="enter" className="extra_hud-hover">
								<span>Войти</span>
							</span>
						</div>

						
					</div>
				</header>
			</div>
		)
	}
	
}