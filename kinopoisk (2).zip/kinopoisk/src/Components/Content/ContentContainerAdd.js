import { Component } from "react";
import ContentTrailer from "./ContentTrailer";
import ContentInner from "./ContentInner";
import "./index.css"

export default class ContentContainerAdd extends Component {

    constructor (props) {
        super(props)
    }
    
    trailer_path = `https://youtube.com/embed/${this.props.movie.videos.results[0].key}`

    render(){
        return(
            <div id="abebsa">
                <ContentInner movie={this.props.movie} poster={this.props.poster}/>
                <ContentTrailer trailer_path={this.trailer_path}/>
            </div>
        )
    }
}