let ContentInner = (props) => {
    const poster_path = `https://image.tmdb.org/t/p/w500/${props.poster}`;
    const style = {
        backgroundImage: "url(" + poster_path + ")",
        backgroundSize: "100%",
        backgroundRepeat: "no-repeat",
        backgroundPosition : "center",
        width: "30%",
        height: "100%",
    };

    
    return(
        <div id="inner">
            <div className = "movie_poster" style={style}></div>
            <div className="contant">
                <div id="name">{props.movie.title}</div>
                <div id="information">{props.movie.overview}</div>
                <div className="buttons">
                    <button className="try abibi">
                        <div className="triangle-right"></div>
                        Смотреть
                    </button>
                    <button className="will"> + Буду Смотреть</button>
                </div>
            </div>
        </div>
    )


}

export default ContentInner;