import { Component } from "react";


export default class Footer extends Component {

    amongus() {
        let amog = document.getElementById("amongus");
        this.amongus.addAttribute()
    }
    render(){
        return (
            <footer>
                <div id="fir-part">
                    <div id="images">
                        <img className="extra_hud-hover flex" src="https://avatars.mds.yandex.net/get-bunker/118781/0ae3d1ca27d3794204beec7d3810025f8c2b7e87/svg"/>
                        <img className="extra_hud-hover flex" src="https://avatars.mds.yandex.net/get-bunker/61205/97123f0bc0c689932a2fb6b62d3ab8ce04d7e936/svgs"/>
                        <img className="extra_hud-hover flex" src="https://avatars.mds.yandex.net/get-bunker/56833/9f570502e378d5e28a5a173a273fa811c4490a73/svg"/>
                        <img className="extra_hud-hover flex" src="https://avatars.mds.yandex.net/get-bunker/128809/65fe1abdd405eb82aec7490588a1ec6745d9ab87/svg"/>
                    </div>
                    <div id="help">
                        <div className="extra_hud-hover flex">Вакансии</div>
                        <div className="extra_hud-hover flex">Реклама</div>
                        <div className="extra_hud-hover flex">Соглашение</div>
                        <div className="extra_hud-hover flex">Справка</div>
                        <div className="extra_hud-hover flex">Блог</div>
                        <div className="extra_hud-hover flex">Участие в исследованиях</div>
                        <div className="extra_hud-hover flex">Предложения</div>
                        <div className="extra_hud-hover flex">Служба поддержки</div>
                    </div>
                    <div id="buttons">
                        <img src="https://avatars.mds.yandex.net/get-bunker/50064/9de0796ad18834328b4d4858b524bf8ce6f31f98/svg" className="baton"/>
                        <img src="https://avatars.mds.yandex.net/get-bunker/994123/d4d889eb60c34ed8ca7d3c0fe965b8327e229fcf/svg" className="baton"/>
                        <img src="https://avatars.mds.yandex.net/get-bunker/128809/1b6561563c22de1014279a528719f4f7d9360296/svg" className="baton"/>
                    </div>
                </div>
                <hr id="hra"/>
                <div id="last-part">
                    <div id="apishka">
                        <span className="extra_hud-hover flex abebsus">Телепрограмма</span>
                        <span className="extra_hud-hover flex abebsus">Музыка</span>
                        <span className="extra_hud-hover flex abebsus">Афиша</span>
                    </div>
                    <div id="project"></div>
                </div>
            </footer>
        )
    }
}

//https://www.citypng.com/public/uploads/preview/-516082589985okuaxeyxp.png
//https://www.citypng.com/public/uploads/small/51608258907ydvosttmdlctvgjmuwxtjsop8ana6mel52wfgacclp3xpnew4cpsc0b6ggfkqmpbyftuvqnsi3ltv1dzcv5f7j4dnaecv6g2do8p.png
//