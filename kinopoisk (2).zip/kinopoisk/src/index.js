import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import ContentMain from './Components/ContentMain';
import ContentBiletItem from './Components/ContentBilet/ContentBiletsItem';
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";

const api_key = "11d710652c50152a07e72edb5890aad2"
let api_url = "https://api.themoviedb.org"
const tmdb_url = 'https://www.themoviedb.org/movie'

const image_url = 'https://image.tmdb.org/t/p/w500'
const language = 'en-us'



class App extends React.Component {
	constructor(props) {
		super(props)

		this.state = {
			featuredMovieData: null,
			movieData: this.discover()
		}
	}	

  	discover(type="movie", genre="") {
    	fetch(`${api_url}/3/discover/${type}?api_key=${api_key}&language=${language}&with_genres=${genre}`)
    	.then(response => response.json())
    	.then(data => {
			let movieList = []
			let arrayId = []
      		const results = data.results
      		results.forEach((movie) => {
				if(movie.poster_path === null) return
				if(movie.vote_average) {
					const movieBox = <ContentBiletItem movie={movie} key={movie.id} />
					movie.poster_link = `${image_url}${movie.poster_path}`
					movie.url = `${tmdb_url}${movie.id}`
					movieList.push(movieBox)
					arrayId.push(movie.id)
					console.log(arrayId)
				}
			  })
			fetch(`${api_url}/3/${type}/${results[0].id}?api_key=${api_key}&append_to_response=credits,videos`)
			.then(response => response.json())
			.then(data => {
				this.setState({ featuredMovieData: data, movieData: movieList })
			})
    	})
  	}

	

  	

  	

  	render() {
		console.log(this.state.movieData)
    	return (
			<div className="App">
				{this.state.movieData
					? <div>
						<Header />
						<ContentMain movie={this.state.featuredMovieData} list={this.state.movieData}/>
						<Footer />
					</div>
					: null
				}
			</div>
    	)
  	}
}




const root = ReactDOM.createRoot(document.getElementById('root'));
root.render( 
        <App/>
);